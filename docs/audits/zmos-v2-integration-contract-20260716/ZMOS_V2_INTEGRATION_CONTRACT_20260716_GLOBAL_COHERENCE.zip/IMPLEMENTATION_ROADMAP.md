TIMESTAMP: 2026-07-15T22:21:33.3735918+02:00

# Roadmap d’implémentation conditionnelle

ID: ZMOS-V2-CONTRACT-ROADMAP-001  
META_ID: META-ZMOS-V2-CONTRACT-ROADMAP-001  
TRACE_ID: TRC-ZMOS-V2-INTEGRATION-20260715-001  
RUN_ID: RUN-20260715-222133  
GUARD_IDS: NO_CODE_WITHOUT_FRED_GO, CROSS_AUDIT_REQUIRED, PROGRESSIVE_ACTIVATION  
STATUS: BLOCKED_BY_APPROVAL_CHAIN

## Gate préalable

Aucun code avant : validation ChatGPT, audit Codex A, audit Codex B indépendant, convergence Claude, puis GO explicite Fred. Les quatre revues doivent viser le même `SPEC_ID` et les mêmes SHA des 14 livrables.

## Séquence

1. Geler V1 du contrat et ses vecteurs de canonicalisation.
2. Résoudre les décisions bloquantes de `GLOBAL_IMPACT_BEFORE_BUILD.md`.
3. Exécuter LOT 0 en documentation/tests rouges uniquement.
4. Construire LOTS 1–2 sur store jetable, sans connexion ZORAN ni historique.
5. Prouver crash/retry/idempotence/corruption et audit indépendant.
6. Adapter extérieurement 00→08 puis 09→10; conserver les moteurs purs.
7. Ajouter 11 uniquement après certification séparée d’ENGINE-11.
8. Prouver `reconstruct_run` sur golden runs et adversarial runs.
9. Activer bridge en canari limité : `READONLY → SIMULATION → ACTIVATION_LIMITÉE → ACTIF_ENCADRÉ`.
10. Tester recovery/endurance; seulement ensuite soumettre un paquet de promotion historique.

## Gates de chaque étape

Tests rouges devenus verts sans régression; revue sécurité; rollback démontré; historique delta zéro; SHA et rapports signés; métriques avec numérateur/dénominateur; aucun warning transformé en PASS; GO Fred spécifique au lot. Un échec P0 force retour au dernier mode stable, pas une correction opportuniste.

## Ownership proposé à valider

Product owner : Fred. Contrat : ChatGPT. Construction : acteur explicitement désigné. Audits : Codex A/B indépendants. Convergence : Claude. Promotion historique : opérateur ZMOS autorisé distinct du runtime.


TIMESTAMP: 2026-07-15T22:21:33.3735918+02:00

# Contrat du bridge d’écriture

ID: ZMOS-V2-CONTRACT-WRITE-001  
META_ID: META-ZMOS-V2-CONTRACT-WRITE-001  
TRACE_ID: TRC-ZMOS-V2-INTEGRATION-20260715-001  
RUN_ID: RUN-20260715-222133  
GUARD_IDS: SINGLE_WRITER, ATOMIC_AGGREGATE, FAIL_CLOSED, IDEMPOTENT  
STATUS: PARTIEL — spécification prête, implémentation interdite

## Producteur et entrée

Les moteurs restent purs et retournent leurs objets en mémoire. L’orchestrateur assemble une enveloppe remise à un writer unique : objets, relations, événements, preuves, `transaction_id`, `idempotency_key`, `expected_previous_state`, identité du caller et autorisation.

## Validation avant préparation

Schémas connus; identités et SHA recalculés; code producteur résolu; parents existants; relations autorisées; horloge injectée; autorité présente; ordre causal acyclique sauf relations explicitement déclarées non causales; quotas respectés. Échec ⇒ aucun `PREPARED` durable visible.

## Commit et reçu

Le writer compare `expected_previous_state`, verrouille le run, écrit l’agrégat, force la durabilité, puis émet un reçu append-only scellé contenant transaction, run, état avant/après, ensemble trié des IDs/SHA, racine de manifeste, séquence, horodatage et identité du writer. Le reçu n’est retourné qu’après durabilité prouvée.

## Retry, doublons et crash

- Retry avec même clé : retour du reçu existant sans nouvel objet.
- Même clé, contenu différent : `IDEMPOTENCY_CONFLICT`.
- Même OBJECT_ID, contenu différent : `IDENTITY_COLLISION`.
- Crash avant commit : récupération vers ABORTED ou reprise idempotente.
- Crash après durabilité mais avant réponse : le retry retrouve le reçu.
- Orphelin : transaction refusée; scanner périodique signale tout écart sans le réparer automatiquement.

## ZMOS DOWN

Si la persistance est obligatoire, le pipeline s’arrête avant tout effet externe et renvoie `PERSISTENCE_REQUIRED_UNAVAILABLE`. Aucun moteur aval, action ou clôture ne peut être présenté comme commité. Une file locale différée n’est permise que si elle est elle-même le store transactionnel durable certifié; une mémoire RAM ou un journal best-effort ne suffit pas.

## Rollback

Un commit immutable n’est pas supprimé. Une compensation crée une nouvelle transaction autorisée liant l’état antérieur, l’anomalie et le recovery point. L’effet externe possède son propre mécanisme de compensation; le writer ne falsifie jamais l’historique.


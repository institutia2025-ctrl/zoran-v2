TIMESTAMP: 2026-07-15T22:21:33.3735918+02:00

# Politique de protection du store historique

ID: ZMOS-V2-CONTRACT-PROTECT-001  
META_ID: META-ZMOS-V2-CONTRACT-PROTECT-001  
TRACE_ID: TRC-ZMOS-V2-INTEGRATION-20260715-001  
RUN_ID: RUN-20260715-222133  
GUARD_IDS: EXISTING_FIRST, HISTORICAL_STORE_READ_ONLY, NO_DIRECT_PROMOTION  
STATUS: PROUVÉ

## Règles absolues

1. Le fichier historique, ses writers, manifestes et journaux ne sont jamais modifiés par le runtime V2.
2. Les comptes OS et processus V2 reçoivent seulement des droits de lecture sur la racine historique.
3. Aucun chemin de configuration du writer transactionnel ne peut résoudre vers le fichier historique; résolution canonique puis comparaison fail-closed.
4. Aucune migration automatique, aucun trigger, aucune table ajoutée et aucun changement de journal mode.
5. Le store historique n’est jamais requis pour committer un run V2; sa panne ne doit pas corrompre le store transactionnel.
6. La promotion est un export supervisé, reproductible, signé et idempotent, jamais une réplication implicite.

## Source de vérité unique

- Run V2 et son état : store transactionnel.
- Corpus historique déjà indexé : store historique.
- Promotion : projection du store transactionnel vers un paquet d’import certifié. Après promotion, l’objet transactionnel original reste l’autorité; la projection conserve son `OBJECT_ID`, son SHA et un lien `PROMOTED_FROM` défini dans un schéma futur certifié.
- Toute divergence entre projection et objet source est une anomalie bloquante; elle ne crée pas deux vérités concurrentes.

## Contrôles de protection

- Test négatif d’ouverture en écriture du fichier historique par l’identité runtime V2.
- Test de chemin avec symlink/junction, casse, chemin relatif et substitution de configuration.
- Snapshot des compteurs et du manifeste avant/après chaque campagne; delta attendu zéro hors promotion autorisée.
- Surveillance des mtime, taille, journal auxiliaire et SHA quand le fichier peut être lu sans arrêter le service.
- Promotion interdite tant que la dérive live/manifeste (+38/+8/+7/+38 mesurée) n’est pas qualifiée.

## Incident

Toute écriture non supervisée déclenche : arrêt de promotion, conservation des preuves, isolation du writer, comparaison au dernier snapshot, restauration uniquement par l’opérateur historique autorisé. Aucun rollback automatique ne touche la base historique.


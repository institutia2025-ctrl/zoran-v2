TIMESTAMP: 2026-07-15T22:21:33.3735918+02:00

# Synthèse exécutive

ID: ZMOS-V2-CONTRACT-EXEC-001  
META_ID: META-ZMOS-V2-CONTRACT-EXEC-001  
TRACE_ID: TRC-ZMOS-V2-INTEGRATION-20260715-001  
RUN_ID: RUN-20260715-222133  
MISSION_ID: ZMOS_V2_INTEGRATION_CONTRACT  
AI_ACTOR_ID: Codex-Auditeur  
GUARD_IDS: EXISTING_FIRST, READ_ONLY_ABSOLU, NO_BUILD_BEFORE_FRED_GO  
STATUS: FIX_REQUIRED

## Décision

Le contrat d’intégration est définissable sans recréer ZMOS : conservation absolue du sidecar et du graphe historiques en lecture seule, ajout futur d’un store transactionnel distinct, writer externe unique, moteurs 00→11 purs, reconstruction exacte par RUN_ID et promotion supervisée seulement après certification.

## Verrous avant code

La technologie du store, la canonicalisation, l’authentification des autorités/reçus, la politique PII/rétention, les seuils de performance et la procédure de promotion restent à figer. L’interface actuelle doit être considérée `FIX_REQUIRED` car elle consomme un chemin retourné par ZMOS sans contrôle contractuel complet SHA/schéma/identité/provenance.

## Ordre de construction autorisable

Contrats/tests rouges → store jetable → writer atomique → objets 00→08 → décision 09/plan 10 → ENGINE-11 certifié puis clôture → reconstruction → bridge canari → recovery → promotion → benchmark global.

## Gate

État réel : documentation 14/14 produite; runtime 0/10 lots construits; historique 0 mutation. Prochaine décision : soumettre exactement ces artefacts à ChatGPT, Codex A, Codex B et Claude; toute divergence doit être résolue avant GO Fred.

LOW_NOISE · MAX_COHERENCE · TRACEABLE_RUNTIME · MULTICADRE_ONLY


TIMESTAMP: 2026-07-15T22:21:33.3735918+02:00

# Politique d’identité et de provenance

ID: ZMOS-V2-CONTRACT-IDPROV-001  
META_ID: META-ZMOS-V2-CONTRACT-IDPROV-001  
TRACE_ID: TRC-ZMOS-V2-INTEGRATION-20260715-001  
RUN_ID: RUN-20260715-222133  
GUARD_IDS: NO_SELF_ASSERTED_AUTHORITY, CONTENT_BOUND_IDENTITY, LINEAGE_REQUIRED  
STATUS: PARTIEL

## Identités

- `OBJECT_ID` : stable et global dans le namespace/version; lié au contenu et au type selon une convention figée.
- `META_ID` : identité des métadonnées, distincte du contenu métier.
- `TRACE_ID` : corrélation causale transverse.
- `RUN_ID` : agrégat reconstructible unique.
- `PROVENANCE_ID` : référence vers une preuve de provenance résolue, jamais simple texte du producteur.
- `authority_snapshot_id` : snapshot immuable des règles, permissions, catalogues et décisions applicables.

## Autorité

Le producteur ne peut pas s’auto-déclarer autorisé. Le snapshot contient source, version, SHA, portée, validité, acteur certificateur et chaîne de délégation. Catalogue, exécuteur, identité humaine et preuve externe doivent être authentifiés selon leur classe de confiance; rehasher une affirmation ne l’authentifie pas.

## Code et temps

`producer_code_sha` identifie le code réellement chargé, dépendances verrouillées comprises selon le manifeste défini au LOT 0. `created_at_context` est injecté par l’orchestrateur; le moteur pur ne lit pas l’horloge. L’ordre causal repose sur séquence de commit et relations, pas uniquement sur l’heure murale.

## Collisions et réutilisation

Même ID/SHA différent : fail-closed et anomalie. Même contenu sous deux identités : détection et politique de déduplication sans effacer l’historique. Un ID d’un run précédent ne peut être réutilisé comme nouvel événement. Les données sensibles sont pseudonymisées avec alias run-scoped et table protégée séparée.

## Complétude

Tout objet non racine possède au moins un parent causal. Les racines autorisées sont explicitement typées : entrée initiale, snapshot d’autorité ou preuve externe authentifiée. Une provenance manquante, circulaire ou non résolue rend l’objet non commitable.


TIMESTAMP: 2026-07-15T22:21:33.3735918+02:00

# Impact global avant construction

ID: ZMOS-V2-CONTRACT-IMPACT-001  
META_ID: META-ZMOS-V2-CONTRACT-IMPACT-001  
TRACE_ID: TRC-ZMOS-V2-INTEGRATION-20260715-001  
RUN_ID: RUN-20260715-222133  
GUARD_IDS: GLOBAL_IMPACT, NO_BUILD_BEFORE_CONVERGENCE, GAIN_NET  
STATUS: FIX_REQUIRED avant build

## Gains attendus

Traçabilité causale 00→11, distinction plan/exécution, preuve de provenance, fail-closed, replay exact, audit par run et promotion supervisée. Les moteurs restent purs; la complexité est concentrée dans un writer et un reconstructeur externes.

## Coûts et blast radius

- Runtime : nouvelle dépendance obligatoire pouvant stopper le pipeline.
- Données : stockage des prompts/réponses, preuves et autorités; classification, rétention et redaction obligatoires.
- Sécurité : writer privilégié, idempotency abuse, spoofing d’autorité, path trust, falsification de reçu.
- Exploitation : sauvegarde, monitoring, capacity planning, recovery, rotation de secrets et compatibilité de schéma.
- Performance : hash, validation, commit durable et reconstruction; budgets non encore définis.
- Gouvernance : décision humaine et reçus deviennent des dépendances explicites.
- Historique : risque maximal de corruption si séparation/promotion est mal appliquée.

## Invariants avant/après

Avant : bridge lecture non scellé, aucun write/replay 00→11. Après visé : lecture vérifiée, commits atomiques, reconstruction complète, historique inchangé. Aucun gain n’est acquis avant tests; `dS/dt`, latences et delta MVP restent `NON_MESURÉ`.

## Décisions bloquantes

Technologie et emplacement du store; canonicalisation; modèle de signature des reçus; autorité et identité humaine; politique secrets/PII/rétention; modèle d’effets externes; seuils de benchmark; définition exacte des runs sans exécution; procédure de promotion; responsabilité opérateur.

## Verdict menace

HIGH avant mitigations. BLOCKING pour build si l’une des protections P0 du plan rouge n’est pas acceptée. Le contrat documentaire rapproche directement le MVP en supprimant l’ambiguïté, mais ne prouve aucun comportement runtime.


TIMESTAMP: 2026-07-15T22:21:33.3735918+02:00

# Plan de migration challengeable

ID: ZMOS-V2-CONTRACT-MIGRATION-001  
META_ID: META-ZMOS-V2-CONTRACT-MIGRATION-001  
TRACE_ID: TRC-ZMOS-V2-INTEGRATION-20260715-001  
RUN_ID: RUN-20260715-222133  
GUARD_IDS: READONLY_TO_SIMULATION_TO_LIMITED, LOT_GATED, FRED_GO_REQUIRED  
STATUS: FIX_REQUIRED avant build

## Lots 0 à 10

| Lot | Objectif | Fichiers prévus | Dépendances | Impact global | Tests rouges initiaux | PASS / FAIL | Rollback | Delta MVP estimé | GO Fred |
|---|---|---|---|---|---|---|---|---|---|
| 0 | Figer schémas, canonicalisation, erreurs et autorités | schemas/, contract/, vectors/ | audits A/B, ChatGPT, Claude | base déterministe | champs/relations invalides acceptés | PASS: vecteurs inter-implémentations identiques; FAIL: ambiguïté | retirer version non activée | INDIRECT, NON_MESURÉ | validation des 4 parties |
| 1 | Store séparé durable | config + module store + migrations propres au nouveau store | lot 0, choix techno/ACL | nouvelle vérité des runs | chemin historique accepté, crash perd données | PASS: isolation/durabilité; FAIL: contact historique | supprimer store jetable, config off | DIRECT, NON_MESURÉ | techno, chemin, budget validés |
| 2 | Writer atomique unique | writer/orchestrator + receipts | lots 0–1 | persistance fail-closed | demi-commit/double commit | PASS: fault injection exhaustive; FAIL: état partiel | feature flag off + store jetable | DIRECT, NON_MESURÉ | audit sécurité et recovery |
| 3 | Objets/relations 00→08 | adapters externes + schemas | lot 2, contrats moteurs | lineage pré-décision | parent/provenance manquant | PASS: chaque run partiel reconstructible; FAIL: objet auto-déclaré | désactiver adapters | DIRECT, NON_MESURÉ | convergence sur mapping |
| 4 | Décision 09 et plan 10 | adapters 09/10 | lot 3, autorité | gouvernance de décision | plan marqué exécuté | PASS: décision scellée, plan non exécuté; FAIL: confusion état | désactiver 09/10 | DIRECT, NON_MESURÉ | Fred valide sémantique humaine |
| 5 | Clôture 11 certifiée | adapter 11 | ENGINE-11 intégré/certifié, lot 4 | clôture fiable | fermeture sans reçu | PASS: tous parents/reçus; FAIL: fermeture prématurée | adapter 11 off | DIRECT, NON_MESURÉ | GO séparé ENGINE-11 |
| 6 | Reconstruction read-only | reconstructeur + CLI/API RO | lots 0–5 | audit exact | corruption non détectée | PASS: golden runs byte-identiques; FAIL: trou causal | retirer endpoint RO | DIRECT, NON_MESURÉ | audit confidentialité |
| 7 | Bridge runtime | read/write clients + config | lots 2,6 | intégration produit | SHA non revérifié, fallback silencieux | PASS: fail-closed E2E; FAIL: consommation divergente | config bridge off | DIRECT, NON_MESURÉ | canari limité autorisé |
| 8 | Recovery/corruption | runbooks + outils supervisés | lots 1–7 | résilience | power-loss, bitflip, partition | PASS: aucun faux commit; FAIL: perte/altération | restauration snapshot jetable | INDIRECT, NON_MESURÉ | opérateur/DR validés |
| 9 | Promotion supervisée | export package + validator | certification 0–8, dérive qualifiée | enrichit historique | mutation directe, double vérité | PASS: paquet signé/idempotent; FAIL: writer runtime historique | ne pas importer/restore opérateur | INDIRECT, NON_MESURÉ | GO promotion par lot |
| 10 | Benchmark/certification globale | harness + rapports signés | lots précédents | décision d’activation | seuils non définis | PASS: seuils convenus et endurance; FAIL: toute régression | rester en mode précédent | DIRECT, NON_MESURÉ | ChatGPT+A+B+Claude+Fred |

## Challenge de l’ordre proposé

Le LOT 6 doit démarrer en parallèle conceptuel dès LOT 0 par golden vectors, mais son activation vient après objets 00→11. Le LOT 7 ne doit pas précéder la preuve du writer et du reconstructeur. Le LOT 9 est facultatif pour le MVP transactionnel et ne doit jamais bloquer l’existence du store V2. LOT 5 reste indépendant d’ENGINE-11 jusqu’à certification.


TIMESTAMP: 2026-07-15T22:21:33.3735918+02:00

# Contrat du bridge de lecture

ID: ZMOS-V2-CONTRACT-READ-001  
META_ID: META-ZMOS-V2-CONTRACT-READ-001  
TRACE_ID: TRC-ZMOS-V2-INTEGRATION-20260715-001  
RUN_ID: RUN-20260715-222133  
GUARD_IDS: VERIFY_BEFORE_CONSUME, FAIL_CLOSED, NO_PATH_TRUST  
STATUS: FIX_REQUIRED pour l’interface actuelle

## Séquence obligatoire

1. Interroger le sidecar avec timeout, limites et encodage strict.
2. Recevoir identité, SHA annoncé, schéma, provenance et localisation.
3. Résoudre le chemin canonique et vérifier qu’il appartient aux racines autorisées; refuser traversée, junction ou périphérique inattendu.
4. Ouvrir en lecture stable, recalculer SHA256 sur les octets consommés et comparer en temps constant au SHA annoncé.
5. Parser avec le schéma versionné attendu et limites de taille/profondeur.
6. Vérifier que l’`OBJECT_ID` recalculé ou embarqué correspond à l’identité annoncée.
7. Vérifier `PROVENANCE_ID`, parents et autorité contre une source approuvée; une valeur auto-déclarée n’est pas une preuve.
8. Injecter uniquement le contenu vérifié et tracer résultat, SHA, version, source et décision.

## Fail-closed

SHA divergent, objet absent, schéma inconnu, provenance non résolue, chemin hors racine, fichier changeant pendant lecture, réponse partielle, timeout ou sidecar DOWN ⇒ objet non consommé. Le moteur reçoit une erreur typée et aucune donnée issue de cet objet. Le fallback éventuel doit être explicitement autorisé par la politique du run et ne peut se présenter comme lecture ZMOS réussie.

## TOCTOU

Le SHA doit porter sur le même handle/flux que les octets parsés. Métadonnées avant/après lecture ou mécanisme équivalent détectent le remplacement concurrent. Le bridge ne fait pas confiance au seul chemin renvoyé.

## Preuve de lecture

Créer un événement `READ_VERIFIED` ou `READ_REJECTED` contenant : run, trace, objet, SHA annoncé/calculé, schéma, provenance, source, horodatage injecté et code de décision. Aucun contenu secret dans les logs.


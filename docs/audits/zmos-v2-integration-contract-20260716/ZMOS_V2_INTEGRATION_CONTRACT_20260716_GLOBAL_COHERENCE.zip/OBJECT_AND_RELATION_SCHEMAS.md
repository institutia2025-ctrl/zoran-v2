TIMESTAMP: 2026-07-15T22:21:33.3735918+02:00

# Schémas objets et relations

ID: ZMOS-V2-CONTRACT-SCHEMA-001  
META_ID: META-ZMOS-V2-CONTRACT-SCHEMA-001  
TRACE_ID: TRC-ZMOS-V2-INTEGRATION-20260715-001  
RUN_ID: RUN-20260715-222133  
GUARD_IDS: OBJECT_FIRST, RELATION_AS_OBJECT, VERSIONED_SCHEMA  
STATUS: PARTIEL — formalisation JSON Schema requise au LOT 0

## Enveloppe objet minimale

Champs obligatoires : `OBJECT_ID`, `META_ID`, `TRACE_ID`, `RUN_ID`, `PROVENANCE_ID`, `schema_version`, `producer_component`, `producer_code_sha`, `CONTENT_SHA256`, `parent_object_ids`, `authority_snapshot_id`, `created_at_context`, `status`, `object_type`, `payload`.

Contraintes : identifiants non vides et conformes à une grammaire versionnée; SHA256 hex 64; parents triés et uniques; timestamp fourni par le contexte; payload validé selon `object_type`; champs inconnus rejetés pour les versions strictes. `status` décrit la réalité (`PRODUCED`, `VALIDATED`, `PLANNED`, `EXECUTED`, `CLOSED`, `REJECTED`, `ANOMALOUS`) et ne peut anticiper un événement.

## Relation comme objet scellé

Champs : mêmes identités de base, `relation_type`, `source_object_id`, `target_object_id`, `relation_schema_version`, `evidence_object_ids`, `ordinal`, `causal`, `payload`, `CONTENT_SHA256`. La relation possède son propre `OBJECT_ID`; source et cible seules ne suffisent pas à son identité.

Types autorisés V1 : `PRODUCED_BY`, `DERIVED_FROM`, `CONSUMED_BY`, `BELONGS_TO_RUN`, `BELONGS_TO_TRACE`, `USES_SCHEMA`, `USES_AUTHORITY`, `VALIDATES`, `REPLAYS`, `AUTHORIZED_BY`, `EXECUTED_BY`, `CLOSED_BY`, `HAS_ANOMALY`, `HAS_RECOVERY_POINT`.

Chaque type définit cardinalité, direction, types source/cible, causalité et preuve minimale. Un type inconnu ou une inversion est rejeté. `EXECUTED_BY` exige un reçu d’exécution indépendant; `AUTHORIZED_BY` une décision humaine vérifiable; `CLOSED_BY` une clôture 11 valide.

## Objets par moteur

00 état runtime; 01 découverte/provenance; 02 frame; 03 opérants/opérés; 04 référentiel; 05 métriques/vetos; 06 aliases privés run-scoped; 07 échange LLM et reçu fournisseur; 08 validation post-LLM; 09 décision; 10 plan; 11 clôture. Les aliases 06 ne deviennent jamais des identités globales.

## Canonicalisation

UTF-8, normalisation Unicode définie, clés triées, nombres et dates normalisés, absence de valeurs non finies. Le LOT 0 doit figer les vecteurs de test avant tout code.


TIMESTAMP: 2026-07-15T22:21:33.3735918+02:00

# Architecture ZMOS existante — référence obligatoire

ID: ZMOS-V2-CONTRACT-ARCH-001  
META_ID: META-ZMOS-V2-CONTRACT-ARCH-001  
TRACE_ID: TRC-ZMOS-V2-INTEGRATION-20260715-001  
RUN_ID: RUN-20260715-222133  
MISSION_ID: ZMOS_V2_INTEGRATION_CONTRACT  
AI_ACTOR_ID: Codex-Auditeur  
GUARD_IDS: EXISTING_FIRST, READ_ONLY_ABSOLU, HISTORICAL_STORE_IMMUTABLE  
SPEC_ID: ZMOS_V2_INTEGRATION_CONTRACT_V1  
STATUS: PROUVÉ

## Vérité existante

- Racine : `C:\Users\frede\Desktop\Zoran Core 05 07 2026\00_SOMMAIRE_START_HERE`.
- Sidecar actif : `zoran_memory_platform.py`, SHA256 `E8A19E1635EAEA0ABE68AA01B15C249312F6C7E9AE885D079DA24B6AAE17FFB4`.
- Endpoint : `127.0.0.1:8910`; version : `ZMOS_V1_20260705`.
- Store : `ZORAN_KNOWLEDGE_GRAPH_V1_INDEX.sqlite`, SQLite/FTS5, journal mode `delete`.
- État live : 439744 artifacts, 445123 nodes, 3791958 edges, 439744 entrées FTS.
- Écart au manifeste : +38 artifacts, +8 nodes, +7 edges, +38 FTS. Cet écart doit être qualifié avant promotion.
- Writers batch : `zoran_full_folder_artifact_engine_v2_20260705.py` et `zoran_knowledge_graph_v1_20260705.py`.
- Reader runtime : `zoran_memory_platform.py`.
- Journaux séparés : `ZORAN_EXPERIENCE_LOG.jsonl` et `AAAZORAN_AI_WORKLOG.jsonl`.

## Flux réel

`ZORAN api/server.py → GET dashboard/search → sidecar 8910 → SQLite/FTS → chemin local → lecture fichier par ZORAN`.

Le sidecar ne fournit aucun endpoint transactionnel pour les objets des moteurs 00→11. `POST /api/aaazoran` est un worklog et ne constitue pas ce bridge. La base historique est un index de connaissances batch, pas un journal transactionnel de runs.

## Frontières de confiance

1. ZORAN ↔ sidecar HTTP local.
2. Sidecar ↔ SQLite historique.
3. Résultat de recherche ↔ fichier local mutable.
4. Futur writer ↔ store transactionnel distinct.
5. Store transactionnel certifié ↔ procédure supervisée de promotion historique.

Invariant : aucun composant V2 ne transforme le graphe historique en source transactionnelle primaire. Le store transactionnel est source de vérité des runs V2; le graphe historique reste une projection certifiée et dérivée.

Sources : rapports read-only `REAL_ZMOS_RUNTIME_IDENTITY.json`, `REAL_ZMOS_STORES_WRITERS_READERS.json`, `REAL_ZORAN_ZMOS_INTERFACE_MAP.json`.


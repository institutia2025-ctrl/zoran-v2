TIMESTAMP: 2026-07-15T22:21:33.3735918+02:00

# Contrat `reconstruct_run(RUN_ID)`

ID: ZMOS-V2-CONTRACT-REPLAY-001  
META_ID: META-ZMOS-V2-CONTRACT-REPLAY-001  
TRACE_ID: TRC-ZMOS-V2-INTEGRATION-20260715-001  
RUN_ID: RUN-20260715-222133  
GUARD_IDS: EXACT_RECONSTRUCTION, READ_ONLY_REPLAY, COMPLETENESS_PROOF  
STATUS: PARTIEL

## Entrée et sortie

Entrée : un `RUN_ID` exact et une politique de divulgation. Sortie : paquet immuable ordonné contenant entrée initiale, sorties 00→11, DAG causal, référentiel, échange LLM, décision 09, plan 10, décision humaine, résultat d’exécution, clôture 11, anomalies, code producteur, autorités, reçus et preuve de complétude.

## Algorithme contractuel

1. Charger le manifeste commité du run et vérifier son reçu.
2. Charger tous les objets/relations listés, recalculer leurs SHA et schémas.
3. Vérifier appartenance run/trace, parents, cardinalités et absence d’orphelins.
4. Construire l’ordre causal par relations et ordinal de commit; refuser les cycles causaux.
5. Vérifier les jalons obligatoires selon l’état final du run.
6. Produire un paquet canonique et sa racine SHA.
7. Émettre `COMPLETE`, `INCOMPLETE`, `CORRUPT` ou `UNAUTHORIZED`; jamais de complétion supposée.

## Exactitude

« Exacte » signifie identité des octets canoniques et de l’ordre causal enregistrés, non reproduction stochastique d’un appel LLM. Le replay restitue la requête/réponse enregistrée; une réexécution éventuelle est un nouveau run relié par `REPLAYS`.

## Preuve de complétude

Liste triée attendue/réelle des objets, relations et événements; racine de manifeste; plages de séquence sans trou; contraintes par moteur; état humain/exécution cohérent. Une clôture 11 sans décision humaine ou reçu d’exécution requis est `INCOMPLETE`.

## Confidentialité

Le reconstructeur est read-only, applique les autorisations au champ et produit une preuve de redaction. Un paquet redacted n’est pas annoncé byte-identical au paquet complet.


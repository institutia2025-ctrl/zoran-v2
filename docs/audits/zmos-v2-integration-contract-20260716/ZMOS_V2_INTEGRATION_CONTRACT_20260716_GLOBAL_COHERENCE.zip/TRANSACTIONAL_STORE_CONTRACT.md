TIMESTAMP: 2026-07-15T22:21:33.3735918+02:00

# Contrat du store transactionnel distinct

ID: ZMOS-V2-CONTRACT-STORE-001  
META_ID: META-ZMOS-V2-CONTRACT-STORE-001  
TRACE_ID: TRC-ZMOS-V2-INTEGRATION-20260715-001  
RUN_ID: RUN-20260715-222133  
GUARD_IDS: OBJECT_FIRST, ATOMIC_COMMIT, APPEND_ONLY_RECEIPT, EXACT_REPLAY  
STATUS: PARTIEL — technologie physique à sélectionner après GO

## Responsabilité

Le store conserve la vérité transactionnelle immuable des runs ZORAN V2. Il est physiquement et logiquement distinct de SQLite historique. Une seule API de writer possède les droits d’écriture; moteurs, API produit, sidecar historique et reconstruction sont lecteurs.

## Agrégat atomique

Une transaction contient : `transaction_id`, `idempotency_key`, `expected_previous_state`, objets, relations, événements, preuves, manifeste de complétude et reçu. Le commit rend visible l’ensemble ou rien. Aucun lecteur ne voit un état intermédiaire.

## États

`PREPARED → COMMITTED` ou `PREPARED → ABORTED`. Après crash : `PREPARED` est récupéré déterministement; jamais interprété comme `COMMITTED`. Un run peut être `OPEN`, `WAITING_HUMAN`, `EXECUTION_PENDING`, `CLOSED`, `ANOMALOUS`; seul un commit reçu change l’état.

## Invariants

- Un `OBJECT_ID` désigne un contenu canonique unique. Même ID + SHA différent = collision bloquante.
- Même `idempotency_key` + même enveloppe = même reçu; enveloppe différente = conflit.
- Toutes les relations référencent des objets présents dans la transaction ou déjà commités.
- Un objet commité n’est jamais mis à jour : correction = nouvel objet et relation de succession à définir/versionner.
- Chaque run a exactement un manifeste de complétude courant, dérivé d’événements immuables.
- Canonicalisation et algorithme de hash sont versionnés; `CONTENT_SHA256` exclut uniquement le champ de hash lui-même et le reçu de commit.

## Exigences non fonctionnelles

Durabilité fsync/équivalent, isolation sérialisable par `RUN_ID`, sauvegarde vérifiée, chiffrement et ACL selon classification des données, horloge injectée, quota/limites, métriques sans contenu sensible. La technologie, les chemins et les seuils restent des décisions de LOT 1.

## Interfaces minimales

`prepare_transaction`, `commit_transaction`, `abort_transaction`, `get_receipt`, `get_object`, `list_run_objects`, `list_run_relations`, `stream_run_events`, `verify_run`, `reconstruct_run`. Les noms sont contractuels, non une prescription de code ou protocole.


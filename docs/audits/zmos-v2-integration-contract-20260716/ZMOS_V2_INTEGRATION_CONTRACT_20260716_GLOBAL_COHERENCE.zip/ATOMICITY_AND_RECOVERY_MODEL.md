TIMESTAMP: 2026-07-15T22:21:33.3735918+02:00

# Modèle d’atomicité et de recovery

ID: ZMOS-V2-CONTRACT-RECOVERY-001  
META_ID: META-ZMOS-V2-CONTRACT-RECOVERY-001  
TRACE_ID: TRC-ZMOS-V2-INTEGRATION-20260715-001  
RUN_ID: RUN-20260715-222133  
GUARD_IDS: ALL_OR_NOTHING, CRASH_SAFE, RECOVERY_POINT_REQUIRED  
STATUS: PARTIEL

## Machine d’état

`ABSENT → PREPARED → COMMITTED` ou `ABSENT → PREPARED → ABORTED`. Seul `COMMITTED` est lisible comme vérité. `COMMITTED → COMPENSATED` est représenté par une nouvelle transaction, jamais par mutation.

## Ordre de commit

Valider → comparer état attendu → réserver IDs/idempotency → écrire agrégat et manifeste → force durable → enregistrer séquence de commit → sceller reçu → publier visibilité. La publication ne précède jamais la durabilité.

## Recovery

Au démarrage, le writer vérifie journal/WAL, préparations incomplètes, reçus sans manifeste, manifestes sans reçu, orphelins, collisions et monotonicité des séquences. Il isole l’anomalie, ne devine pas l’intention et n’exécute aucun effet externe. Chaque correction opérationnelle exige `HAS_RECOVERY_POINT` et autorisation.

## Menaces concrètes

| ID | Cause | Impact | Preuve | Mitigation/test |
|---|---|---|---|---|
| T1 | crash entre données et reçu | faux échec ou double commit | journal + fault injection | retry retrouve exactement un reçu |
| T2 | clé idempotente réutilisée | substitution | enveloppes signées | conflit fail-closed |
| T3 | parent absent | graphe orphelin | scan référentiel | transaction rejetée |
| T4 | fichier historique ciblé | corruption patrimoine | ACL + chemin résolu | test d’écriture refusée |
| T5 | action avant commit | exécution non traçable | timeline/reçu | interdire effet avant reçu |
| T6 | reçu falsifié | fausse preuve | signature/MAC selon modèle | vérification indépendante |
| T7 | corruption silencieuse | replay faux | scrub SHA/manifestes | quarantaine + recovery point |

Verdict de menace avant build : HIGH; BLOCKING si atomicité, ACL historique ou récupération crash ne sont pas démontrées.

